package com.flowgate.repository;

import com.flowgate.model.WorkflowLog;
import org.springframework.data.jpa.repository.JpaRepository;

public interface WorkflowLogRepository extends JpaRepository<WorkflowLog, Long> {
}