package com.flowgate.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "workflow_logs")
public class WorkflowLog {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long workflowId;

    private String action;

    private String performedBy;

    private LocalDateTime createdAt;

    public WorkflowLog() {
        this.createdAt = LocalDateTime.now();
    }

    public Long getId() { return id; }

    public Long getWorkflowId() { return workflowId; }

    public String getAction() { return action; }

    public String getPerformedBy() { return performedBy; }

    public LocalDateTime getCreatedAt() { return createdAt; }

    public void setWorkflowId(Long workflowId) { this.workflowId = workflowId; }

    public void setAction(String action) { this.action = action; }

    public void setPerformedBy(String performedBy) { this.performedBy = performedBy; }
}