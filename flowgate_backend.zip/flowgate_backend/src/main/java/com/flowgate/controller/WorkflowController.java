package com.flowgate.controller;

import com.flowgate.model.Workflow;
import com.flowgate.model.WorkflowLog;
import com.flowgate.repository.WorkflowLogRepository;
import com.flowgate.repository.WorkflowRepository;

import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.*;

@RestController
@RequestMapping("/api/workflows")
@CrossOrigin("*")
public class WorkflowController {

    private final WorkflowRepository workflowRepository;
    private final WorkflowLogRepository workflowLogRepository;

    public WorkflowController(
            WorkflowRepository workflowRepository,
            WorkflowLogRepository workflowLogRepository
    ) {
        this.workflowRepository = workflowRepository;
        this.workflowLogRepository = workflowLogRepository;
    }

    // =====================================
    // CREATE WORKFLOW
    // =====================================

    @PostMapping
    public Workflow create(@RequestBody Workflow workflow) {

        workflow.setStatus("Pending");

        workflow.setCreatedAt(LocalDateTime.now());

        if (workflow.getCreatedBy() == null) {
            workflow.setCreatedBy("Employee");
        }

        if (workflow.getAssignedTo() == null) {
            workflow.setAssignedTo("Admin");
        }

        Workflow saved = workflowRepository.save(workflow);

        // SAVE LOG
        WorkflowLog log = new WorkflowLog();

        log.setWorkflowId(saved.getId());

        log.setAction("Workflow Created");

        log.setPerformedBy(saved.getCreatedBy());

        workflowLogRepository.save(log);

        return saved;
    }

    // =====================================
    // GET ALL WORKFLOWS
    // =====================================

    @GetMapping
    public List<Workflow> getAll() {

        return workflowRepository.findAll();
    }

    // =====================================
    // GET WORKFLOW BY ID
    // =====================================

    @GetMapping("/{id}")
    public Workflow getById(@PathVariable Long id) {

        return workflowRepository.findById(id)
                .orElseThrow(() ->
                        new RuntimeException("Workflow Not Found"));
    }

    // =====================================
    // APPROVE WORKFLOW
    // =====================================

    @PutMapping("/{id}/approve")
    public Workflow approve(@PathVariable Long id) {

        Workflow workflow = workflowRepository.findById(id)
                .orElseThrow(() ->
                        new RuntimeException("Workflow Not Found"));

        workflow.setStatus("Approved");

        workflow.setApprovedBy("Admin");

        workflow.setApprovedAt(LocalDateTime.now());

        workflowRepository.save(workflow);

        // SAVE LOG
        WorkflowLog log = new WorkflowLog();

        log.setWorkflowId(workflow.getId());

        log.setAction("Workflow Approved");

        log.setPerformedBy("Admin");

        workflowLogRepository.save(log);

        return workflow;
    }

    // =====================================
    // REJECT WORKFLOW
    // =====================================

    @PutMapping("/{id}/reject")
    public Workflow reject(@PathVariable Long id) {

        Workflow workflow = workflowRepository.findById(id)
                .orElseThrow(() ->
                        new RuntimeException("Workflow Not Found"));

        workflow.setStatus("Rejected");

        workflow.setApprovedBy("Admin");

        workflow.setApprovedAt(LocalDateTime.now());

        workflowRepository.save(workflow);

        // SAVE LOG
        WorkflowLog log = new WorkflowLog();

        log.setWorkflowId(workflow.getId());

        log.setAction("Workflow Rejected");

        log.setPerformedBy("Admin");

        workflowLogRepository.save(log);

        return workflow;
    }

    // =====================================
    // WORKFLOW HISTORY
    // =====================================

    @GetMapping("/{id}/history")
    public List<WorkflowLog> history(@PathVariable Long id) {

        return workflowLogRepository.findByWorkflowId(id);
    }

    // =====================================
    // DASHBOARD
    // =====================================

    @GetMapping("/dashboard")
    public Map<String, Object> dashboard() {

        List<Workflow> workflows = workflowRepository.findAll();

        long pending = workflows.stream()
                .filter(w ->
                        "Pending".equalsIgnoreCase(w.getStatus()))
                .count();

        long approved = workflows.stream()
                .filter(w ->
                        "Approved".equalsIgnoreCase(w.getStatus()))
                .count();

        long rejected = workflows.stream()
                .filter(w ->
                        "Rejected".equalsIgnoreCase(w.getStatus()))
                .count();

        long inReview = workflows.stream()
                .filter(w ->
                        "In Review".equalsIgnoreCase(w.getStatus()))
                .count();

        long drafts = workflows.stream()
                .filter(w ->
                        "Draft".equalsIgnoreCase(w.getStatus()))
                .count();

        Map<String, Object> data = new HashMap<>();

        // IMPORTANT FRONTEND FIELDS

        data.put("totalWorkflows", workflows.size());

        data.put("pendingCount", pending);

        data.put("approvedCount", approved);

        data.put("rejectedCount", rejected);

        data.put("inReviewCount", inReview);

        data.put("draftCount", drafts);

        data.put("recentWorkflows", workflows);

        data.put("myPendingApprovals", new ArrayList<>());

        return data;
    }

    // =====================================
    // SEARCH WORKFLOW
    // =====================================

    @GetMapping("/search")
    public List<Workflow> search(
            @RequestParam String q
    ) {

        return workflowRepository
                .findByTitleContainingIgnoreCase(q);
    }
}